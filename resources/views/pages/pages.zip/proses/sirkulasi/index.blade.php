@extends('layouts.main')

@push('css')
    <link href="{{ asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <style>
        .select2-container .select2-selection--single {
            height: calc(2.5rem + 2px);
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            border: 1px solid #ced4da;
            border-radius: 0.375rem;
            box-shadow: inset 0 1px 2px rgb(0 0 0 / 8%);
        }
        .select2-container .select2-selection--single:focus {
            border-color: #86b7fe;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        .select2-container--default .select2-selection--single .select2-selection__placeholder {
            color: #6c757d;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            padding-left: 0;
        }
        .select2-container .select2-dropdown {
            border: 1px solid #ced4da;
            border-radius: 0.375rem;
            box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.1);
            z-index: 1055;
        }
        .select2-container .select2-results__option {
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
        }
        .select2-container .select2-results__option--highlighted {
            background-color: #e9ecef;
            color: #212529;
        }
        .card-img-top {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
@endpush

@section('content')
    <div class="page-content">
        @include('components.alertsComponents')
        <div class="">
            <div class="card card-custom">
                <div class="card-body">
                    <div class="d-flex flex-column align-items-center">
                        <h2 class="text-dark-75 text-center">Management Sirkulasi</h2>
                        <p class="text-dark-50 text-center">Silahkan Atur Data Sirkulasi untuk menambah atau mengelola data peminjaman buku.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header">
                <h5>Konfigurasi Denda</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.sirkulasi.updateDenda') }}" method="POST">
                    @csrf
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="denda" class="form-label">Denda per Hari (Rp)</label>
                            <input type="text" class="form-control" id="denda" name="denda" value="{{ number_format($denda->jumlah ?? 0, 0, ',', '.') }}" required>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
            </div>
        </div>


        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-start">
                    <button class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#tambahSirkulasi">
                        Tambah Peminjaman
                    </button>
                </div>
            </div>
        </div>




  <!-- Modal -->
  <div class="modal fade" id="tambahSirkulasi" tabindex="-1" aria-labelledby="tambahSirkulasiLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="tambahSirkulasiLabel">Tambah Peminjaman</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form action="{{ route('admin.sirkulasi.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="row h-100">
                        <div class="col-md-8 d-flex flex-column">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <p class="card-title text-warning mb-2">Pilih Anggota</p>
                                        <select class="form-select mb-3" name="member_id" id="member_id" required>
                                            <option value="" selected disabled>Pilih Anggota</option>
                                            @foreach ($members as $member)
                                                <option value="{{ $member->id }}">{{ $member->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="row g-2 mt-2">
                                            <div class="col-md-6">
                                                <label for="tgl_pinjam" class="form-label text-info">Tanggal Pinjam</label>
                                                <input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="tgl_kembali" class="form-label text-primary">Tanggal Kembali</label>
                                                <input type="date" class="form-control" id="tgl_kembali" name="tgl_kembali" required>
                                            </div>
                                        </div>

                                        
                                    </div>
                                </div>
                            </div>
                    
                      <div class="card mb-3">
                                <div class="card-body">
                                    <div class="input-group " >
                                        <input type="text" class="form-control" placeholder="Cari buku..." x-model="searchQuery" @input="handleSearch">
                                        <span class="input-group-text"><i class="bx bx-search"></i></span>
                            </div>
                        </div>
                      </div>
                       
                    <div class="row g-3">
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="1">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="2">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 d-flex justify-content-center">
                            <div class="card shadow-sm" style="max-width: 90%; height: auto;">
                                <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="Buku IPS" style="height: 140px; object-fit: cover;">
                                <div class="card-body d-flex flex-column p-3">
                                    <h6 class="card-title text-info text-center">Ilmu Pengetahuan Sosial</h6>
                                    <ul class="list-group list-group-flush flex-grow-1 small">
                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                        <li class="list-group-item">Pengarang: John Doe</li>
                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                    </ul>
                                    <div class="d-grid mt-2">
                                        <button class="btn btn-outline-primary btn-sm select-book" type="button" data-book-id="3">Pilih Buku</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        </div>
                        <div class="col-md-4 d-flex flex-column">
                            <div class="card shadow border-0  ">
                                <div class="card-body">
                                    <h5 class="card-title text-info">Rincian Peminjaman</h5>
                                    <label for="memberName">Nama Anggota:</label>
                                    <input type="text" id="memberName" value="Ucok Saepudin" class="form-control bg-light" disabled>
                                        <div class="w-50 pr-2" style="margin-right: 5px">
                                            <label for="borrowDate" class="mt-3">Tanggal Peminjaman:</label>
                                            <input type="text" id="borrowDate" value="01 Februari 2025" class="form-control" disabled>
                                        </div>
                                        <div class="w-50 pl-2">
                                            <label for="returnDate" class="mt-3">Tanggal Dikembalikan:</label>
                                            <input type="text" id="returnDate" value="10 Februari 2025" class="form-control" disabled>
                                        </div>
                                </div>
                            </div>

                            
                            <div class="card shadow border-0 ">
                                <div class="card-body">
                                    <div class="d-flex align-items-center border p-2 mb-2">
                                        <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="me-3" alt="Buku 1" style="width: 20%">
                                        <div class="flex-grow-1">
                                            <h6>Ilmu Pengetahuan Sosial</h6>
                                            <li class="list-group-item">ISBN: 123-456-789</li>
                                            <li class="list-group-item">Pengarang: John Doe</li>
                                            <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                            <li class="list-group-item">Tahun Terbit: 2024</li>
                                        </div>
                                        <input type="number" class="form-control w-25 me-3" value="1" min="1">
                                    </div>
                                    <div class="d-flex align-items-center border p-2 mb-2">
                                        <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="me-3" alt="Buku 1" style="width: 20%">
                                        <div class="flex-grow-1">
                                            <h6>Ilmu Pengetahuan Sosial</h6>
                                            <li class="list-group-item">ISBN: 123-456-789</li>
                                            <li class="list-group-item">Pengarang: John Doe</li>
                                            <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                            <li class="list-group-item">Tahun Terbit: 2024</li>
                                        </div>
                                        <input type="number" class="form-control w-25 me-3" value="1" min="1">
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="selectedBooks" name="selectedBooks">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer d-flex justify-content-between align-items-center">
            <div class="pagination text-start">
                <nav aria-label="Page navigation">
                    <ul class="pagination mb-0">
                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-success">Simpan</button>
            </div>
        </div>
      </div>
    </div>
  </div>












        <div class="card">
            {{-- <div class="modal fade " id="tambahSirkulasi" aria-labelledby="tambahSirkulasiLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable modal-fullscreen">
                    <div class="modal-content">
                        <form action="{{ route('admin.sirkulasi.store') }}" method="POST">
                            @csrf
                            <div class="modal-header">
                                <h5 class="modal-title" id="tambahSirkulasiLabel">Tambah Peminjaman</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row h-100">
                                    <div class="col-md-8 d-flex flex-column">
                                        <div class="col-12">
                                            <div class="card shadow border-0">
                                                <div class="card-body">
                                                    <p class="card-title text-warning mb-2">Pilih Anggota</p>
                                                    <select class="form-select mb-3" name="member_id" id="member_id" required>
                                                        <option value="" selected disabled>Pilih Anggota</option>
                                                        @foreach ($members as $member)
                                                            <option value="{{ $member->id }}">{{ $member->name }}</option>
                                                        @endforeach
                                                    </select>
                                                    <div class="row g-2 mt-2">
                                                        <div class="col-md-6">
                                                            <label for="tgl_pinjam" class="form-label text-info">Tanggal Pinjam</label>
                                                            <input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="tgl_kembali" class="form-label text-primary">Tanggal Kembali</label>
                                                            <input type="date" class="form-control" id="tgl_kembali" name="tgl_kembali" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row flex-grow-1 ">
                                            <div class="col-md-4  d-flex">
                                                <div class="card h-100 w-100">
                                                    <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="..." style="height: 170px; object-fit: cover;">
                                                    <div class="card-body d-flex flex-column">
                                                        <h5 class="card-title text-info">Ilmu Pengetahuan Sosial</h5>
                                                        <ul class="list-group list-group-flush flex-grow-1">
                                                            <li class="list-group-item">ISBN: 123-456-789</li>
                                                            <li class="list-group-item">Pengarang: John Doe</li>
                                                            <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                                            <li class="list-group-item">Tahun Terbit: 2024</li>
                                                        </ul>
                                                        <div class="d-grid" style="margin-top: -20px">
                                                            <button class="btn btn-outline-primary select-book" type="button" data-book-id="1">Pilih Buku</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4  d-flex">
                                                <div class="card h-100 w-100">
                                                    <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="..." style="height: 170px; object-fit: cover;">
                                                    <div class="card-body d-flex flex-column">
                                                        <h5 class="card-title text-info">Ilmu Pengetahuan Sosial</h5>
                                                        <ul class="list-group list-group-flush flex-grow-1">
                                                            <li class="list-group-item">ISBN: 123-456-789</li>
                                                            <li class="list-group-item">Pengarang: John Doe</li>
                                                            <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                                            <li class="list-group-item">Tahun Terbit: 2024</li>
                                                        </ul>
                                                        <div class="d-grid" style="margin-top: -20px">
                                                            <button class="btn btn-outline-primary select-book" type="button" data-book-id="1">Pilih Buku</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4  d-flex">
                                                <div class="card h-100 w-100">
                                                    <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="card-img-top" alt="..." style="height: 170px; object-fit: cover;">
                                                    <div class="card-body d-flex flex-column">
                                                        <h5 class="card-title text-info">Ilmu Pengetahuan Sosial</h5>
                                                        <ul class="list-group list-group-flush flex-grow-1">
                                                            <li class="list-group-item">ISBN: 123-456-789</li>
                                                            <li class="list-group-item">Pengarang: John Doe</li>
                                                            <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                                            <li class="list-group-item">Tahun Terbit: 2024</li>
                                                        </ul>
                                                        <div class="d-grid" style="margin-top: -20px">
                                                            <button class="btn btn-outline-primary select-book" type="button" data-book-id="1">Pilih Buku</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 d-flex flex-column">
                                        <div class="card shadow border-0  ">
                                            <div class="card-body">
                                                <h5 class="card-title text-info">Rincian Peminjaman</h5>
                                                <label for="memberName">Nama Anggota:</label>
                                                <input type="text" id="memberName" value="Ucok Saepudin" class="form-control bg-light" disabled>
                                                <div class="d-flex justify-content-between">
                                                    <div class="w-50 pr-2" style="margin-right: 5px">
                                                        <label for="borrowDate" class="mt-3">Tanggal Peminjaman:</label>
                                                        <input type="text" id="borrowDate" value="01 Februari 2025" class="form-control" disabled>
                                                    </div>
                                                    <div class="w-50 pl-2">
                                                        <label for="returnDate" class="mt-3">Tanggal Dikembalikan:</label>
                                                        <input type="text" id="returnDate" value="10 Februari 2025" class="form-control" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card shadow border-0 ">
                                            <div class="card-body">
                                                <div class="d-flex align-items-center border p-2 mb-2">
                                                    <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="me-3" alt="Buku 1" style="width: 20%">
                                                    <div class="flex-grow-1">
                                                        <h6>Ilmu Pengetahuan Sosial</h6>
                                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                                        <li class="list-group-item">Pengarang: John Doe</li>
                                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                                    </div>
                                                    <input type="number" class="form-control w-25 me-3" value="1" min="1">
                                                </div>
                                                <div class="d-flex align-items-center border p-2 mb-2">
                                                    <img src="https://www.grafika27.com/wp-content/uploads/2022/05/IPS-BS-KLS-VII-COVER.jpg" class="me-3" alt="Buku 1" style="width: 20%">
                                                    <div class="flex-grow-1">
                                                        <h6>Ilmu Pengetahuan Sosial</h6>
                                                        <li class="list-group-item">ISBN: 123-456-789</li>
                                                        <li class="list-group-item">Pengarang: John Doe</li>
                                                        <li class="list-group-item">Penerbit: Penerbit Contoh</li>
                                                        <li class="list-group-item">Tahun Terbit: 2024</li>
                                                    </div>
                                                    <input type="number" class="form-control w-25 me-3" value="1" min="1">
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" id="selectedBooks" name="selectedBooks">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer d-flex justify-content-between align-items-center">
                                <div class="pagination text-start">
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination mb-0">
                                            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                        </ul>
                                    </nav>
                                </div>
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    <button type="submit" class="btn btn-success">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> --}}
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-sm-8">
                        <div class="d-flex justify-content-between">
                            <h5 class="card-title">Data Sirkulasi</h5>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Cari data..." x-model="searchQuery" @input="handleSearch">
                            <span class="input-group-text"><i class="bx bx-search"></i></span>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table  class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center" scope="col">No</th>
                                <th class="text-center" scope="col">Buku</th>
                                <th class="text-center" scope="col">Peminjam</th>
                                <th class="text-center" scope="col">Tanggal Pinjam</th>
                                <th class="text-center" scope="col">Jatuh Tempo</th>
                                <th class="text-center" scope="col">Denda (Rp)</th>
                                <th class="text-center" scope="col" style="width:10%;">Total Terlambat (Hari)</th>
                                <th class="text-center" scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center">1</td>
                                <td class="text-center">Harry Potter dan Batu Bertuah</td>
                                <td class="text-center">Budi Santoso</td>
                                <td class="text-center">2024-01-10</td>
                                <td class="text-center">2024-01-17</td>
                                <td class="text-center">10.000</td>
                                <td class="text-center">2</td>
                                <td class="text-center">
                                    <button class="btn btn-danger btn-sm">Bayar Denda</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">2</td>
                                <td class="text-center">Laskar Pelangi</td>
                                <td class="text-center">Siti Aisyah</td>
                                <td class="text-center">2024-01-05</td>
                                <td class="text-center">2024-01-12</td>
                                <td class="text-center">20.000</td>
                                <td class="text-center">4</td>
                                <td class="text-center">
                                    <button class="btn btn-danger btn-sm">Bayar Denda</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">3</td>
                                <td class="text-center">Bumi</td>
                                <td class="text-center">Ahmad Fauzan</td>
                                <td class="text-center">2024-01-08</td>
                                <td class="text-center">2024-01-15</td>
                                <td class="text-center">5.000</td>
                                <td class="text-center">1</td>
                                <td class="text-center">
                                    <button class="btn btn-danger btn-sm">Bayar Denda</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">4</td>
                                <td class="text-center">Dilan 1990</td>
                                <td class="text-center">Rina Permata</td>
                                <td class="text-center">2024-01-02</td>
                                <td class="text-center">2024-01-09</td>
                                <td class="text-center">25.000</td>
                                <td class="text-center">5</td>
                                <td class="text-center">
                                    <button class="btn btn-danger btn-sm">Bayar Denda</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">5</td>
                                <td class="text-center">Negeri 5 Menara</td>
                                <td class="text-center">Doni Saputra</td>
                                <td class="text-center">2024-01-12</td>
                                <td class="text-center">2024-01-19</td>
                                <td class="text-center">0</td>
                                <td class="text-center">0</td>
                                <td class="text-center">
                                    <button class="btn btn-success btn-sm" disabled>Lunas</button>
                                </td>
                            </tr>

                            {{-- @foreach ($circulations as $circulation)
                                <tr>
                                    <th scope="row" class="text-center">{{ $loop->iteration }}</th>
                                    <td>{{ $circulation->book->judul }}</td>
                                    <td>{{ $circulation->member->name }}</td>
                                    <td>{{ $circulation->tgl_pinjam }}</td>
                                    <td>{{ $circulation->tgl_kembali }}</td>
                                    <td>
                                        @php
                                            $today = \Carbon\Carbon::today();
                                            $tglKembali = \Carbon\Carbon::parse($circulation->tgl_kembali);
                                            $totalTerlambat = $tglKembali->isPast() ? $tglKembali->diffInDays($today) : 0;
                                            $dendaTerlambat = $totalTerlambat > 0 ? $totalTerlambat * $denda->jumlah : 0;
                                            $totalDenda = $circulation->denda + $dendaTerlambat;
                                        @endphp
                                        @if ($totalDenda == 0)
                                            Rp. 0
                                        @else
                                            <span class="text-danger fw-bold">Rp. {{ number_format($totalDenda, 0, ',', '.') }}</span>
                                        @endif
                                    </td>
                                    <td class="text-center">{{ $totalTerlambat }} Hari</td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#perpanjangModal_{{ $circulation->id }}" title="Perpanjang">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="24" viewBox="0 0 24 24" fill="none" stroke="#f7f7f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus">
                                                    <path d="M5 12h14" />
                                                    <path d="M12 5v14" />
                                                </svg>
                                            </button>
                                            <div class="modal fade" id="perpanjangModal_{{ $circulation->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <form action="{{ route('admin.sirkulasi.extend', $circulation->id) }}" method="post">
                                                            @csrf
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Perpanjang Peminjaman</h1>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="mb-3">
                                                                    <label for="jatuhtempo" class="form-label">Perpanjang Jatuh Tempo</label>
                                                                    <input type="date" class="form-control" id="jatuhtempo" name="jatuhtempo" value="{{ $circulation->tgl_kembali }}">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Save changes</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <form action="{{ route('admin.sirkulasi.return', $circulation->id) }}" method="post" id="delete-form_{{ $circulation->id }}">
                                                @csrf
                                                <button type="button" class="btn btn-danger btn-sm" onclick="deleteConfirm(event, {{ $circulation->id }})" title="Kembalikan">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="24" viewBox="0 0 24 24" fill="none" stroke="#f7f7f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-undo-2">
                                                        <path d="M9 14L4 9l5-5" />
                                                        <path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11" />
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach --}}
                        </tbody>
                    </table>
                </div>
                <div class="">
                    <h5>Notes</h5>
                    <p>Masa peminjaman buku adalah 7 hari dari tanggal peminjaman. Jika buku dikembalikan lebih dari masa peminjaman, maka akan dikenakan denda sebesar Rp {{ number_format($denda->jumlah ?? 1000, 0, ',', '.') }}/hari.</p>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="{{ asset('assets/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="{{ asset('assets/plugins/select2/js/select2-custom.js') }}"></script>
    <script>
        function formatRupiah(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
        }

        document.getElementById('denda').addEventListener('keyup', function(e) {
            this.value = formatRupiah(this.value, 'Rp. ');
        });

        $(document).ready(function() {
            $("#member_id").select2({
                dropdownParent: $("#tambahSirkulasi"),
                placeholder: "Pilih Anggota",
                allowClear: true,
                width: '100%'
            });

            $('#example').DataTable();

            let selectedBooks = new Set();

            let booksTable = $('#booksTable').DataTable({
                'paging': true,
                'info': false,
                'searching': true,
                'ordering': true,
                'drawCallback': function(settings) {
                    $('input[name="book_ids[]"]').each(function() {
                        if (selectedBooks.has($(this).val())) {
                            $(this).prop('checked', true);
                        }
                    });
                }
            });

            $(document).on('click', '.select-book', function() {
                let bookId = $(this).data('book-id');
                if (selectedBooks.has(bookId)) {
                    selectedBooks.delete(bookId);
                    $(this).removeClass('btn-primary').addClass('btn-outline-primary').text('Pilih Buku');
                } else {
                    selectedBooks.add(bookId);
                    $(this).removeClass('btn-outline-primary').addClass('btn-primary').text('Buku Dipilih');
                }
                updateHiddenInput();
            });

            function updateHiddenInput() {
                $('#selectedBooks').val(Array.from(selectedBooks).join(','));
            }

            updateHiddenInput();
        });

        function deleteConfirm(event, id) {
            event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#delete-form_' + id).submit();
                } else {
                    Swal.fire('Cancelled', 'Your data is safe :)', 'error');
                }
            });
        }
    </script>
@endpush
